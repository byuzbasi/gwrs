## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(gwrs)

## ----interface-table, echo=FALSE----------------------------------------------
knitr::kable(data.frame(
  Estimator = c("GWR-Ridge", "GWR-Lasso", "GWR-Elastic Net", "GWR-SCAD", "GWR-MCP"),
  Formula = c("gwr_ridge()", "gwr_lasso()", "gwr_en()", "gwr_scad()", "gwr_mcp()"),
  Matrix = c("gwr_ridge_fit()", "gwr_lasso_fit()", "gwr_en_fit()", "gwr_scad_fit()", "gwr_mcp_fit()")
))

## ----run-example--------------------------------------------------------------
example_file <- system.file("examples", "five-methods.R", package = "gwrs")
source(example_file, local = knitr::knit_global())

## ----selected-penalties-------------------------------------------------------
lapply(cv, function(z) z$best)

## ----coefficients-and-predictions---------------------------------------------
head(coef(cv$scad$fit))
head(as.data.frame(prediction))

## ----regularization-path------------------------------------------------------
path <- gwr_scad_path(x, train$y, coords = coords, k = 18,
  lambda = c(0.2, 0.08, 0.02), control = control)
path$lambda

