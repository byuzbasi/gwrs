#' GWR-style diagnostic F-tests
#'
#' Computes F1 (local model versus global OLS), F2 (joint coefficient
#' stationarity), and coefficient-specific F3 spatial-variability diagnostics.
#' Classical reference distributions are intended for unpenalized Gaussian
#' GWR. Penalized fits require `allow_approximate = TRUE` and are explicitly
#' labelled as conditional exploratory approximations.
#'
#' @param object A least-squares `gwrs_fit` retaining `x` and `y`.
#' @param allow_approximate Permit conditional active-set tests for a penalized
#'   fit.
#' @param ... Unused.
#'
#' @return A `gwrs_diagnostic_tests` object.
#'
#' @examples
#' quake <- datasets::quakes[1:36, ]
#' coords <- as.matrix(quake[, c("long", "lat")])
#' x <- as.matrix(quake[, c("depth", "stations")])
#' fit <- gwr_fit(
#'   x, quake$mag, coords = coords, k = 24,
#'   control = gwrs_control(n_threads = 1)
#' )
#' tests <- gwr_diagnostic_tests(fit)
#' tests$global_tests
#' tests$coefficient_tests
#'
#' @export
gwr_diagnostic_tests <- function(object,
                                 allow_approximate = FALSE,
                                 ...) {
  if (!inherits(object, "gwr_sl_fit") &&
      !inherits(object, "gwr_nonconvex_fit")) {
    stop("F1/F2/F3 diagnostics are defined for Gaussian least-squares GWR fits.",
         call. = FALSE)
  }
  validate_gwrs_diagnostic_object(object, require_x = TRUE)
  if (is.null(object$y)) {
    stop("Refit with `gwrs_control(keep_data = TRUE)` for diagnostic F-tests.",
         call. = FALSE)
  }
  if (object$lambda > 0 && !isTRUE(allow_approximate)) {
    stop(
      "Classical F1/F2/F3 reference distributions do not account for penalization or local selection; set `allow_approximate = TRUE` for labelled conditional diagnostics.",
      call. = FALSE
    )
  }
  diagnostics <- gwr_diagnostics(object)
  standardized_x <- apply_standardization(
    object$x, object$x_center, object$x_scale
  )
  kernel <- kernel_code(object$kernel)
  bandwidth <- diagnostic_bandwidth(object)
  penalty_mode <- switch(
    object$penalty %||% "convex",
    mcp = 1L,
    scad = 2L,
    0L
  )
  components <- cpp_gwr_f_test_components(
    standardized_x,
    t(object$coefficients),
    object$neighbors$index,
    object$neighbors$distance,
    object$x_center,
    object$x_scale,
    kernel$code,
    bandwidth$adaptive,
    bandwidth$fixed,
    object$lambda,
    object[["alpha"]] %||% 1,
    object[["d"]] %||% 0,
    penalty_mode,
    object$gamma %||% 0,
    object$control$n_threads,
    object$control$grain_size
  )
  global_design <- cbind(`(Intercept)` = 1, object$x)
  global_fit <- stats::lm.fit(global_design, object$y)
  global_residuals <- global_fit$residuals
  rss_ols <- sum(global_residuals^2)
  df_ols <- length(object$y) - global_fit$rank
  rss_local <- sum(object$residuals^2)
  q_diag <- as.double(components$q_diag)
  l_delta1 <- sum(q_diag)
  l_delta2 <- sum(q_diag^2)
  delta1 <- length(object$y) - 2 * diagnostics$global$trS +
    diagnostics$global$trStS

  f1 <- (rss_local / l_delta1) / (rss_ols / df_ols)
  f1_df1 <- l_delta1^2 / l_delta2
  f1_df2 <- df_ols
  f1_p <- stats::pf(f1, f1_df1, f1_df2, lower.tail = TRUE)
  f2 <- ((rss_ols - rss_local) / (df_ols - l_delta1)) /
    (rss_ols / df_ols)
  f2_df1 <- (df_ols - l_delta1)^2 /
    (df_ols - 2 * l_delta1 + l_delta2)
  f2_df2 <- df_ols
  f2_p <- stats::pf(f2, f2_df1, f2_df2, lower.tail = FALSE)

  coefficient_sum <- as.matrix(components$coefficient_sum)
  coefficient_sumsq <- as.matrix(components$coefficient_sumsq)
  coefficient_names <- colnames(object$coefficients)
  sigma2_delta1 <- rss_local / delta1
  f3 <- lapply(seq_along(coefficient_names), function(column) {
    beta <- object$coefficients[, column]
    variability <- (sum(beta^2) - sum(beta)^2 / length(beta)) /
      length(beta)
    diag_bj <- (coefficient_sumsq[column, ] -
      coefficient_sum[column, ]^2 / length(beta)) / length(beta)
    gamma1 <- sum(diag_bj)
    gamma2 <- sum(diag_bj^2)
    df1 <- gamma1^2 / gamma2
    statistic <- (variability / gamma1) / sigma2_delta1
    data.frame(
      coefficient = coefficient_names[column],
      statistic = statistic,
      df1 = df1,
      df2 = f1_df1,
      p_value = stats::pf(statistic, df1, f1_df1, lower.tail = FALSE),
      stringsAsFactors = FALSE
    )
  })
  global_tests <- data.frame(
    test = c("F1", "F2"),
    null_hypothesis = c(
      "The local model does not improve on global OLS",
      "All coefficient surfaces are spatially stationary"
    ),
    statistic = c(f1, f2),
    df1 = c(f1_df1, f2_df1),
    df2 = c(f1_df2, f2_df2),
    p_value = c(f1_p, f2_p),
    stringsAsFactors = FALSE
  )
  global_tests <- sanitize_gwr_f_tests(global_tests)
  coefficient_tests <- sanitize_gwr_f_tests(do.call(rbind, f3))
  result <- list(
    global_tests = global_tests,
    coefficient_tests = coefficient_tests,
    diagnostics = list(
      rss_ols = rss_ols,
      rss_local = rss_local,
      df_ols = df_ols,
      trS = diagnostics$global$trS,
      trStS = diagnostics$global$trStS,
      delta1 = delta1,
      L_delta1 = l_delta1,
      L_delta2 = l_delta2
    ),
    validity = list(
      classical = object$lambda <= 0,
      basis = if (object$lambda <= 0) {
        "classical Gaussian GWR smoother"
      } else if (inherits(object, "gwr_nonconvex_fit")) {
        "conditional local-stationary approximation for a nonconvex penalized smoother"
      } else {
        "conditional active-set approximation for a penalized smoother"
      },
      exploratory = object$lambda > 0
    )
  )
  class(result) <- "gwrs_diagnostic_tests"
  result
}

sanitize_gwr_f_tests <- function(table) {
  bad <- !is.finite(table$statistic) | table$statistic < 0 |
    !is.finite(table$df1) | table$df1 <= 0 |
    !is.finite(table$df2) | table$df2 <= 0
  table$statistic[bad] <- NA_real_
  table$df1[bad] <- NA_real_
  table$df2[bad] <- NA_real_
  table$p_value[bad] <- NA_real_
  table
}

#' @export
print.gwrs_diagnostic_tests <- function(x, ...) {
  cat("gwrs GWR-style diagnostic F-tests\n")
  cat("  basis:", x$validity$basis, "\n\n")
  print(x$global_tests, row.names = FALSE)
  cat("\nCoefficient-specific spatial variability tests\n")
  print(x$coefficient_tests, row.names = FALSE)
  if (isTRUE(x$validity$exploratory)) {
    cat("\nNote: penalized-fit tests are conditional exploratory approximations.\n")
  }
  invisible(x)
}
