#' Fast local multicollinearity diagnostics
#'
#' Computes local condition numbers, variance-inflation factors, maximum
#' absolute local correlations, effective sample sizes, and positive kernel
#' counts directly from the reusable nearest-neighbor structure.
#'
#' @param object A fitted `gwrs_fit` retaining its design matrix.
#' @param threshold_cn Condition-number flag threshold.
#' @param threshold_vif VIF flag threshold.
#' @param center Whether predictors are locally centered.
#' @param scale Whether predictors are locally scaled.
#' @param return_pairwise Whether all pairwise local correlations are returned.
#' @param ... Unused.
#'
#' @return A `gwrs_local_collinearity` object.
#'
#' @examples
#' quake <- datasets::quakes[1:36, ]
#' coords <- as.matrix(quake[, c("long", "lat")])
#' x <- as.matrix(quake[, c("depth", "stations")])
#' fit <- gwr_fit(
#'   x, quake$mag, coords = coords, k = 24,
#'   control = gwrs_control(n_threads = 1)
#' )
#' collinearity <- gwr_local_collinearity(fit, return_pairwise = TRUE)
#' head(collinearity$condition_number)
#' head(collinearity$vif_long)
#'
#' @export
gwr_local_collinearity <- function(object,
                                   threshold_cn = 30,
                                   threshold_vif = 10,
                                   center = TRUE,
                                   scale = TRUE,
                                   return_pairwise = FALSE,
                                   ...) {
  validate_gwrs_diagnostic_object(object, require_x = TRUE)
  if (!is.numeric(threshold_cn) || length(threshold_cn) != 1L ||
      !is.finite(threshold_cn) || threshold_cn <= 0 ||
      !is.numeric(threshold_vif) || length(threshold_vif) != 1L ||
      !is.finite(threshold_vif) || threshold_vif <= 0) {
    stop("Collinearity thresholds must be positive finite scalars.",
         call. = FALSE)
  }
  kernel <- kernel_code(object$kernel)
  bandwidth <- diagnostic_bandwidth(object)
  raw <- cpp_gwr_local_collinearity(
    object$x,
    object$neighbors$index,
    object$neighbors$distance,
    kernel$code,
    bandwidth$adaptive,
    bandwidth$fixed,
    isTRUE(center),
    isTRUE(scale),
    isTRUE(return_pairwise),
    object$control$n_threads,
    object$control$grain_size
  )
  predictor_names <- object$predictor_names %||%
    colnames(object$x) %||% paste0("x", seq_len(ncol(object$x)))
  vif <- as.matrix(raw$vif)
  colnames(vif) <- predictor_names
  condition_number <- data.frame(
    location = seq_len(nrow(object$x)),
    condition_number = as.double(raw$condition_number),
    flagged = as.double(raw$condition_number) > threshold_cn
  )
  vif_long <- data.frame(
    location = rep(seq_len(nrow(vif)), times = ncol(vif)),
    predictor = rep(colnames(vif), each = nrow(vif)),
    vif = as.double(vif),
    stringsAsFactors = FALSE
  )
  vif_long$flagged <- vif_long$vif > threshold_vif
  pairwise <- NULL
  if (isTRUE(return_pairwise) && length(predictor_names) > 1L) {
    correlations <- raw$correlations
    pairs <- utils::combn(seq_along(predictor_names), 2L)
    pairwise <- do.call(rbind, lapply(seq_len(ncol(pairs)), function(index) {
      first <- pairs[1L, index]
      second <- pairs[2L, index]
      data.frame(
        location = seq_len(dim(correlations)[3L]),
        predictor_1 = predictor_names[first],
        predictor_2 = predictor_names[second],
        correlation = correlations[first, second, ],
        stringsAsFactors = FALSE
      )
    }))
  }
  result <- list(
    condition_number = condition_number,
    vif = vif,
    vif_long = vif_long,
    max_abs_correlation = as.double(raw$max_abs_correlation),
    effective_sample_size = as.double(raw$effective_sample_size),
    positive_weights = as.integer(raw$positive_weights),
    pairwise_correlations = pairwise,
    thresholds = list(condition_number = threshold_cn, vif = threshold_vif),
    settings = list(center = center, scale = scale, kernel = object$kernel)
  )
  class(result) <- "gwrs_local_collinearity"
  result
}

#' @export
print.gwrs_local_collinearity <- function(x, ...) {
  cat("gwrs local multicollinearity diagnostics\n")
  cat("  condition number median/max:",
      format(stats::median(x$condition_number$condition_number, na.rm = TRUE)),
      "/", format(max(x$condition_number$condition_number, na.rm = TRUE)),
      "\n")
  cat("  locations above threshold:",
      sum(x$condition_number$flagged, na.rm = TRUE), "\n")
  cat("  predictor-location VIF flags:", sum(x$vif_long$flagged, na.rm = TRUE),
      "\n")
  invisible(x)
}

validate_gwrs_diagnostic_object <- function(object, require_x = FALSE) {
  if (!inherits(object, "gwrs_fit")) {
    stop("`object` must inherit from 'gwrs_fit'.", call. = FALSE)
  }
  if (is.null(object$neighbors)) {
    stop("The fitted object does not retain a neighbor structure.",
         call. = FALSE)
  }
  if (require_x && is.null(object$x)) {
    stop("Refit with `gwrs_control(keep_data = TRUE)` for this diagnostic.",
         call. = FALSE)
  }
  invisible(TRUE)
}

diagnostic_bandwidth <- function(object) {
  adaptive <- isTRUE(object$adaptive) || is.null(object$bandwidth)
  list(
    adaptive = adaptive,
    fixed = if (adaptive) 1 else as.double(object$bandwidth)
  )
}
