#' Sparse residual Moran diagnostics
#'
#' Computes global Moran's I and local Moran (LISA) statistics directly from a
#' fitted model's nearest-neighbor graph. Self-neighbor weights are removed and
#' no dense spatial matrix is formed. Permutations use deterministic independent
#' C++ random streams and can be evaluated in parallel.
#'
#' @param object A fitted `gwrs_fit`.
#' @param permutations Number of random permutations; zero skips inference.
#' @param row_standardize Whether non-self spatial weights are row-standardized.
#' @param seed Nonnegative deterministic C++ permutation seed.
#' @param alpha Significance level used for LISA cluster labels.
#' @param ... Unused.
#'
#' @return `gwr_moran()` returns a `gwrs_moran` object. `gwr_local_moran()`
#'   returns a `gwrs_local_moran` data frame.
#'
#' @examples
#' quake <- datasets::quakes[1:36, ]
#' coords <- as.matrix(quake[, c("long", "lat")])
#' x <- as.matrix(quake[, c("depth", "stations")])
#' fit <- gwr_fit(
#'   x, quake$mag, coords = coords, k = 24,
#'   control = gwrs_control(n_threads = 1)
#' )
#' global <- gwr_moran(fit, permutations = 19, seed = 42)
#' local <- gwr_local_moran(fit, permutations = 19, seed = 42)
#' global
#' head(local)
#' plot(local, significant_only = TRUE)
#'
#' @export
gwr_moran <- function(object,
                      permutations = 999L,
                      row_standardize = TRUE,
                      seed = 1L,
                      ...) {
  raw <- compute_gwr_moran(
    object, permutations = permutations,
    row_standardize = row_standardize, seed = seed
  )
  result <- list(
    I = raw$I,
    expected_I = raw$expected_I,
    p_value = raw$p_value,
    permutations = as.integer(permutations),
    n = length(object$residuals),
    kernel = object$kernel,
    adaptive = object$adaptive,
    bandwidth = object$bandwidth,
    row_standardize = isTRUE(row_standardize),
    seed = as.integer(seed),
    permuted_I = raw$permuted_I
  )
  class(result) <- "gwrs_moran"
  result
}

#' @rdname gwr_moran
#' @export
gwr_local_moran <- function(object,
                            permutations = 999L,
                            row_standardize = TRUE,
                            seed = 1L,
                            alpha = 0.05,
                            ...) {
  if (!is.numeric(alpha) || length(alpha) != 1L || !is.finite(alpha) ||
      alpha <= 0 || alpha >= 1) {
    stop("`alpha` must be one number strictly between zero and one.",
         call. = FALSE)
  }
  raw <- compute_gwr_moran(
    object, permutations = permutations,
    row_standardize = row_standardize, seed = seed
  )
  significant <- is.finite(raw$local_p) & raw$local_p <= alpha
  cluster <- rep("Not Significant", length(raw$local_I))
  cluster[significant & raw$centered_residual > 0 & raw$spatial_lag > 0] <-
    "High-High"
  cluster[significant & raw$centered_residual < 0 & raw$spatial_lag < 0] <-
    "Low-Low"
  cluster[significant & raw$centered_residual > 0 & raw$spatial_lag < 0] <-
    "High-Low"
  cluster[significant & raw$centered_residual < 0 & raw$spatial_lag > 0] <-
    "Low-High"
  result <- data.frame(
    location = seq_along(raw$local_I),
    local_I = as.double(raw$local_I),
    z_score = as.double(raw$local_z),
    p_value = as.double(raw$local_p),
    cluster = factor(
      cluster,
      levels = c("Not Significant", "High-High", "Low-Low", "High-Low",
                 "Low-High")
    ),
    residual = as.double(object$residuals),
    residual_centered = as.double(raw$centered_residual),
    spatial_lag = as.double(raw$spatial_lag)
  )
  attr(result, "settings") <- list(
    permutations = permutations,
    row_standardize = row_standardize,
    seed = seed,
    alpha = alpha,
    kernel = object$kernel
  )
  class(result) <- c("gwrs_local_moran", "data.frame")
  result
}

compute_gwr_moran <- function(object, permutations, row_standardize, seed) {
  validate_gwrs_diagnostic_object(object)
  permutations <- as.integer(permutations)
  seed <- as.integer(seed)
  if (length(permutations) != 1L || is.na(permutations) || permutations < 0L ||
      length(seed) != 1L || is.na(seed) || seed < 0L) {
    stop("`permutations` and `seed` must be nonnegative integers.",
         call. = FALSE)
  }
  kernel <- kernel_code(object$kernel)
  bandwidth <- diagnostic_bandwidth(object)
  cpp_gwr_moran(
    as.double(object$residuals),
    object$neighbors$index,
    object$neighbors$distance,
    kernel$code,
    bandwidth$adaptive,
    bandwidth$fixed,
    isTRUE(row_standardize),
    permutations,
    as.double(seed),
    object$control$n_threads,
    object$control$grain_size
  )
}

#' @export
print.gwrs_moran <- function(x, ...) {
  cat("gwrs residual Moran's I\n")
  cat("  I:", format(signif(x$I, 7)), "\n")
  cat("  expected I:", format(signif(x$expected_I, 7)), "\n")
  cat("  permutation p-value:", format.pval(x$p_value, digits = 5), "\n")
  cat("  permutations:", x$permutations, "\n")
  invisible(x)
}

#' @export
plot.gwrs_local_moran <- function(x,
                                  significant_only = FALSE,
                                  alpha = 0.05,
                                  ...) {
  palette <- c(
    "Not Significant" = "grey75", "High-High" = "#D7191C",
    "Low-Low" = "#2C00A0", "High-Low" = "#FDA0A0",
    "Low-High" = "#ABD9E9"
  )
  colors <- unname(palette[as.character(x$cluster)])
  if (isTRUE(significant_only)) {
    colors[!is.finite(x$p_value) | x$p_value > alpha] <- "grey80"
  }
  graphics::plot(
    x$location, x$local_I, pch = 19, col = colors,
    xlab = "Location", ylab = "Local Moran's I",
    main = "Residual LISA", ...
  )
  graphics::abline(h = 0, col = "grey50", lty = 2)
  graphics::legend(
    "topright", legend = names(palette), col = palette, pch = 19,
    bty = "n", cex = 0.8
  )
  invisible(x)
}
