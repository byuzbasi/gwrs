#' Fast Geographically Weighted Regression and Selection
#'
#' The `gwrs` package provides matrix-first and formula interfaces for fast
#' geographically weighted regression, lasso, ridge, elastic net, SCAD, MCP,
#' centered scaled-lasso regularization, robust LAD fitting, and
#' PDE-constrained GWR-KTDD spatial modeling. Registered RcppArmadillo and
#' RcppParallel kernels implement scalar fits, regularization paths, local
#' prediction, KTDD
#' alternating updates, smoother diagnostics, collinearity, residual Moran
#' statistics, and GWR-style F-test components without dense spatial weight or
#' smoother matrices. R remains responsible for validation, formula handling,
#' object assembly, reporting, and visualization.
#'
#' @author Bahadir Yuzbasi
#'
#' @examples
#' quake <- datasets::quakes[1:32, ]
#' coords <- as.matrix(quake[, c("long", "lat")])
#' x <- as.matrix(quake[, c("depth", "stations")])
#' fit <- gwr_lasso_fit(
#'   x, quake$mag, coords = coords, k = 20, lambda = 0.05,
#'   control = gwrs_control(n_threads = 1)
#' )
#' head(coef(fit))
#'
#' @keywords internal
#' @useDynLib gwrs, .registration = TRUE
#' @importFrom Matrix Matrix
#' @importFrom Rcpp evalCpp
#' @importFrom RcppParallel RcppParallelLibs
"_PACKAGE"

utils::globalVariables(".data")
