#include "gwrs_nonconvex.h"

#include <Rcpp.h>

#include <vector>

// [[Rcpp::depends(RcppArmadillo, RcppParallel)]]
// [[Rcpp::plugins(cpp17)]]

namespace {

arma::mat solve_symmetric(const arma::mat& system, const arma::mat& rhs) {
  arma::mat solution;
  const bool ok = arma::solve(
    solution, system, rhs,
    arma::solve_opts::likely_sympd + arma::solve_opts::no_approx
  );
  if (ok && solution.is_finite()) return solution;
  const double scale = std::max(1.0, arma::norm(system, "inf"));
  return arma::pinv(system, scale * 1e-10) * rhs;
}

arma::mat original_scale_map(const arma::mat& standard_map,
                             const arma::vec& x_center,
                             const arma::vec& x_scale) {
  arma::mat result = standard_map;
  arma::rowvec intercept = standard_map.row(0);
  for (arma::uword column = 0; column < x_center.n_elem; ++column) {
    const arma::rowvec slope = standard_map.row(column + 1) / x_scale[column];
    result.row(column + 1) = slope;
    intercept -= x_center[column] * slope;
  }
  result.row(0) = intercept;
  return result;
}

arma::uvec active_set(const arma::mat& coefficients,
                      const arma::uword target,
                      const arma::uword p,
                      const double lambda,
                      const double alpha,
                      const int penalty_mode) {
  if (lambda <= 0.0 || (penalty_mode == 0 && alpha <= 0.0)) {
    return arma::regspace<arma::uvec>(0, p - 1);
  }
  std::vector<arma::uword> active;
  for (arma::uword column = 0; column < p; ++column) {
    if (std::abs(coefficients(column + 1, target)) > 1e-10) {
      active.push_back(column);
    }
  }
  arma::uvec result(active.size());
  for (arma::uword index = 0; index < result.n_elem; ++index) {
    result[index] = active[index];
  }
  return result;
}

struct FComponentWorker : public RcppParallel::Worker {
  const arma::mat& x;
  const arma::mat& coefficients;
  const arma::umat& neighbor_index;
  const arma::mat& neighbor_distance;
  const arma::vec& x_center;
  const arma::vec& x_scale;
  const int kernel;
  const bool adaptive;
  const double fixed_bandwidth;
  const double lambda;
  const double alpha;
  const double d;
  const int penalty_mode;
  const double gamma;

  arma::vec q_diag;
  arma::mat coefficient_sum;
  arma::mat coefficient_sumsq;

  FComponentWorker(
      const arma::mat& x,
      const arma::mat& coefficients,
      const arma::umat& neighbor_index,
      const arma::mat& neighbor_distance,
      const arma::vec& x_center,
      const arma::vec& x_scale,
      const int kernel,
      const bool adaptive,
      const double fixed_bandwidth,
      const double lambda,
      const double alpha,
      const double d,
      const int penalty_mode,
      const double gamma)
    : x(x), coefficients(coefficients), neighbor_index(neighbor_index),
      neighbor_distance(neighbor_distance), x_center(x_center),
      x_scale(x_scale), kernel(kernel), adaptive(adaptive),
      fixed_bandwidth(fixed_bandwidth), lambda(lambda), alpha(alpha), d(d),
      penalty_mode(penalty_mode), gamma(gamma),
      q_diag(x.n_rows, arma::fill::zeros),
      coefficient_sum(x.n_cols + 1, x.n_rows, arma::fill::zeros),
      coefficient_sumsq(x.n_cols + 1, x.n_rows, arma::fill::zeros) {}

  FComponentWorker(FComponentWorker& other, RcppParallel::Split)
    : x(other.x), coefficients(other.coefficients),
      neighbor_index(other.neighbor_index),
      neighbor_distance(other.neighbor_distance), x_center(other.x_center),
      x_scale(other.x_scale), kernel(other.kernel), adaptive(other.adaptive),
      fixed_bandwidth(other.fixed_bandwidth), lambda(other.lambda),
      alpha(other.alpha), d(other.d), penalty_mode(other.penalty_mode),
      gamma(other.gamma),
      q_diag(x.n_rows, arma::fill::zeros),
      coefficient_sum(x.n_cols + 1, x.n_rows, arma::fill::zeros),
      coefficient_sumsq(x.n_cols + 1, x.n_rows, arma::fill::zeros) {}

  void operator()(std::size_t begin, std::size_t end) {
    const arma::uword n = x.n_rows;
    const arma::uword p = x.n_cols;
    const arma::uword k = neighbor_index.n_rows;
    const double lambda2 = lambda * (1.0 - alpha);
    arma::mat x_local(k, p, arma::fill::zeros);
    arma::mat x_local_centered(k, p, arma::fill::zeros);
    arma::mat weighted_x(k, p, arma::fill::zeros);
    arma::vec weights(k, arma::fill::zeros);
    arma::vec normalized_weights(k, arma::fill::zeros);
    arma::vec sqrt_weights(k, arma::fill::zeros);
    arma::rowvec x_mean(p, arma::fill::zeros);

    for (std::size_t target = begin; target < end; ++target) {
      bool valid = true;
      for (arma::uword row = 0; row < k; ++row) {
        const arma::uword encoded = neighbor_index(row, target);
        if (encoded == 0 || encoded > n) {
          valid = false;
          break;
        }
        x_local.row(row) = x.row(encoded - 1);
      }
      if (!valid) continue;
      double bandwidth_used = 0.0;
      const double weight_sum = gwrs::compute_kernel_weights(
        neighbor_distance, target, kernel, adaptive, fixed_bandwidth,
        weights, bandwidth_used
      );
      if (!std::isfinite(weight_sum) ||
          weight_sum <= gwrs::kNumericalEpsilon) continue;
      normalized_weights = weights / weight_sum;
      x_mean = normalized_weights.t() * x_local;
      x_local_centered = x_local;
      x_local_centered.each_row() -= x_mean;
      sqrt_weights = arma::sqrt(normalized_weights);
      weighted_x = x_local_centered;
      weighted_x.each_col() %= sqrt_weights;
      const arma::mat gram = weighted_x.t() * weighted_x;
      arma::mat score_map = x_local_centered.t();
      score_map.each_row() %= normalized_weights.t();
      arma::mat gwr_map;
      if (penalty_mode == 0) {
        gwr_map = solve_symmetric(gram, score_map);
      }
      const arma::uvec active = active_set(
        coefficients, target, p, lambda, alpha, penalty_mode
      );
      arma::mat derivative(p, k, arma::fill::zeros);
      if (active.n_elem > 0) {
        arma::mat system = gram.submat(active, active);
        arma::mat rhs = score_map.rows(active);
        if (penalty_mode == 0) {
          system.diag() += lambda2;
          rhs += lambda2 * d * gwr_map.rows(active);
        } else {
          const int nonconvex_penalty = penalty_mode - 1;
          for (arma::uword index = 0; index < active.n_elem; ++index) {
            const double coefficient =
              coefficients(active[index] + 1, target);
            system(index, index) +=
              gwrs::nonconvex_penalty_second_derivative(
                std::abs(coefficient), lambda, gamma, nonconvex_penalty
              );
          }
        }
        derivative.rows(active) = solve_symmetric(system, rhs);
      }
      arma::mat standard_map(p + 1, k, arma::fill::zeros);
      standard_map.rows(1, p) = derivative;
      standard_map.row(0) = normalized_weights.t() - x_mean * derivative;
      const arma::mat coefficient_map = original_scale_map(
        standard_map, x_center, x_scale
      );
      const arma::rowvec focus_centered = x.row(target) - x_mean;
      const arma::vec smoother_row = normalized_weights +
        derivative.t() * focus_centered.t();
      q_diag[target] += 1.0;
      for (arma::uword row = 0; row < k; ++row) {
        const arma::uword source = neighbor_index(row, target) - 1;
        q_diag[source] += smoother_row[row] * smoother_row[row];
        if (source == target) q_diag[target] -= 2.0 * smoother_row[row];
        coefficient_sum.col(source) += coefficient_map.col(row);
        coefficient_sumsq.col(source) += arma::square(coefficient_map.col(row));
      }
    }
  }

  void join(const FComponentWorker& rhs) {
    q_diag += rhs.q_diag;
    coefficient_sum += rhs.coefficient_sum;
    coefficient_sumsq += rhs.coefficient_sumsq;
  }
};

} // anonymous namespace

// [[Rcpp::export]]
Rcpp::List cpp_gwr_f_test_components(
    const arma::mat& x,
    const arma::mat& coefficients,
    const arma::umat& neighbor_index,
    const arma::mat& neighbor_distance,
    const arma::vec& x_center,
    const arma::vec& x_scale,
    const int kernel,
    const bool adaptive,
    const double fixed_bandwidth,
    const double lambda,
    const double alpha,
    const double d,
    const int penalty_mode,
    const double gamma,
    const int n_threads,
    const int grain_size) {
  if (coefficients.n_rows != x.n_cols + 1 ||
      coefficients.n_cols != x.n_rows ||
      neighbor_index.n_cols != x.n_rows ||
      neighbor_distance.n_cols != x.n_rows ||
      neighbor_index.n_rows != neighbor_distance.n_rows) {
    Rcpp::stop("incompatible F-test input dimensions");
  }
  if (penalty_mode < 0 || penalty_mode > 2 ||
      (penalty_mode > 0 &&
       (!std::isfinite(gamma) ||
        (penalty_mode == 1 && gamma <= 1.0) ||
        (penalty_mode == 2 && gamma <= 2.0)))) {
    Rcpp::stop("invalid F-test penalty mode or gamma");
  }
  FComponentWorker worker(
    x, coefficients, neighbor_index, neighbor_distance, x_center, x_scale,
    kernel, adaptive, fixed_bandwidth, lambda, alpha, d,
    penalty_mode, gamma
  );
  if (n_threads == 1 || x.n_rows < 2) {
    worker(0, x.n_rows);
  } else {
    RcppParallel::parallelReduce(
      0, x.n_rows, worker,
      static_cast<std::size_t>(std::max(1, grain_size)), n_threads
    );
  }
  return Rcpp::List::create(
    Rcpp::_ ["q_diag"] = worker.q_diag,
    Rcpp::_ ["coefficient_sum"] = worker.coefficient_sum,
    Rcpp::_ ["coefficient_sumsq"] = worker.coefficient_sumsq
  );
}
