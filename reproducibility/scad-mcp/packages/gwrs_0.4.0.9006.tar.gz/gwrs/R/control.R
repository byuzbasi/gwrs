#' Control numerical fitting in `gwrs`
#'
#' @param tolerance Relative coefficient convergence tolerance.
#' @param max_iterations Maximum number of solver iterations per location.
#' @param n_threads Number of parallel worker threads. Use `1` for serial
#'   execution or `-1` to let `RcppParallel` choose.
#' @param grain_size Minimum number of target locations assigned per parallel
#'   task.
#' @param keep_data Whether fitted objects retain the training matrices.
#' @param diagnostics Statistical diagnostic level. `"standard"` computes
#'   compact fit and effective-degrees-of-freedom diagnostics, `"full"` also
#'   retains quantities needed for local coefficient inference, and `"none"`
#'   skips statistical diagnostics. Logical values remain supported for
#'   backward compatibility (`TRUE` maps to `"standard"`). Numerical solver
#'   diagnostics are always retained because they are small and are required
#'   to audit convergence.
#' @param nonconvex_solver Gaussian SCAD/MCP solver: `"coordinate"` retains
#'   the legacy updates and failure behavior (default); `"guarded_block"`
#'   adds objective-decreasing pair and flat-tail QR proposals. In guarded
#'   mode a failed target stops its remaining lambda path. CV scores require
#'   convergence for every held-out observation. Other estimators ignore this
#'   option. No environment variable is needed.
#' @param convex_path_solver Lasso/elastic-net prediction-path solver.
#'   `"coordinate"` preserves the default implementation;
#'   `"guarded_acceleration"` uses objective-decreasing sweep extrapolation
#'   for positive lambda, `d = 0` paths without statistical diagnostics.
#'   `"guarded_block"` additionally proposes fixed-orthant QR block steps,
#'   retaining the lasso and elastic-net penalties. Proposals are attempted
#'   every 25 sweeps after at least 5 unchanged signed-support sweeps, with
#'   at most 128 nonzero coefficients. These are computation limits, not
#'   variable-selection limits. Rank-deficient or nondecreasing proposals
#'   are rejected without changing the iterate. Convergence is not guaranteed.
#'   Ridge, zero-lambda, shifted-shrinkage, diagnostic and single-fit branches
#'   retain their original solvers. Applies to path and cross-prediction calls,
#'   not single-fit refits. Weights, stopping rules and iteration caps are unchanged.
#'   `"guarded_working_set"` instead selects at most 128 coordinates by descending
#'   KKT violation (ties by column index), even when the full support is larger.
#'   Each proposal makes at most 8 QR-based signed active-set updates, allowing
#'   coefficients to reach zero and re-enter with a KKT-directed sign inside the
#'   selected block. Only a strict decrease of the original full objective is
#'   published. The same 25-sweep/5-stable-sweep scheduling applies. Additional
#'   QR work, boundary hits and inner limits are reported separately from outer
#'   iterations. After the relative coefficient-change rule is met, this mode
#'   requires both the full KKT residual to be no larger than
#'   `tolerance * (1 + lambda1)` and the relative primal-dual gap to be no
#'   larger than `max(10 * tolerance, 256 * .Machine$double.eps)`. After a
#'   failed certificate, every excluded coordinate whose KKT violation exceeds
#'   `tolerance * (1 + lambda1)` is added deterministically to the screening
#'   set. Ordinary sweeps, guarded extrapolation and scheduled bounded QR
#'   screen fits then continue under the same iteration cap. A scheduled
#'   screen fit repeats an accepted 8-update QR batch while that batch reaches
#'   its inner limit, with at most 16 batches (128 updates) per event. It stops
#'   earlier after rejection or an incomplete batch. Every published batch
#'   strictly decreases the original objective. The 128-coordinate QR limit is
#'   only an acceleration-workspace limit: it neither truncates the fitted
#'   support nor caps the screening set. There is no immediate QR polish and no
#'   all-coordinate fallback. Certificate, screen-expansion and screen-fit
#'   counters are reported separately.
#'   This is a computation option, not a different penalty or a guarantee of
#'   convergence or speed. Earlier options keep their behavior.
#'
#' @return A list of class `gwrs_control`.
#'
#' @examples
#' control <- gwrs_control(
#'   tolerance = 1e-6,
#'   max_iterations = 500,
#'   n_threads = 1,
#'   diagnostics = "full"
#' )
#' control
#'
#' @export
gwrs_control <- function(tolerance = 1e-7,
                         max_iterations = 1000L,
                         n_threads = -1L,
                         grain_size = 16L,
                         keep_data = TRUE,
                         diagnostics = TRUE,
                         nonconvex_solver = c("coordinate", "guarded_block"),
                         convex_path_solver = c("coordinate", "guarded_acceleration", "guarded_block", "guarded_working_set")) {
  nonconvex_solver <- match.arg(nonconvex_solver)
  convex_path_solver <- match.arg(convex_path_solver)
  if (!is.numeric(tolerance) || length(tolerance) != 1L ||
      !is.finite(tolerance) || tolerance <= 0) {
    stop("`tolerance` must be one positive finite number.", call. = FALSE)
  }
  max_iterations <- as.integer(max_iterations)
  n_threads <- as.integer(n_threads)
  grain_size <- as.integer(grain_size)
  if (is.na(max_iterations) || max_iterations < 1L) {
    stop("`max_iterations` must be a positive integer.", call. = FALSE)
  }
  if (is.na(n_threads) || n_threads == 0L || n_threads < -1L) {
    stop("`n_threads` must be -1 or a positive integer.", call. = FALSE)
  }
  if (is.na(grain_size) || grain_size < 1L) {
    stop("`grain_size` must be a positive integer.", call. = FALSE)
  }
  diagnostic_level <- normalize_diagnostic_level(diagnostics)
  structure(
    list(
      tolerance = tolerance,
      max_iterations = max_iterations,
      n_threads = n_threads,
      grain_size = grain_size,
      keep_data = isTRUE(keep_data),
      diagnostics = diagnostic_level != "none",
      diagnostic_level = diagnostic_level,
      nonconvex_solver = nonconvex_solver,
      convex_path_solver = convex_path_solver
    ),
    class = "gwrs_control"
  )
}

validate_control <- function(control) {
  if (is.null(control)) return(gwrs_control())
  if (!inherits(control, "gwrs_control")) {
    stop("`control` must be created with `gwrs_control()`.", call. = FALSE)
  }
  if (is.null(control$diagnostic_level)) {
    control$diagnostic_level <- normalize_diagnostic_level(
      control$diagnostics %||% TRUE
    )
  }
  control$nonconvex_solver <- match.arg(
    control$nonconvex_solver %||% "coordinate", c("coordinate", "guarded_block")
  )
  control$convex_path_solver <- match.arg(
    control$convex_path_solver %||% "coordinate", c("coordinate", "guarded_acceleration", "guarded_block", "guarded_working_set")
  )
  control
}

normalize_diagnostic_level <- function(diagnostics) {
  if (is.logical(diagnostics)) {
    if (length(diagnostics) != 1L || is.na(diagnostics)) {
      stop("`diagnostics` must be one logical value or a diagnostic level.",
           call. = FALSE)
    }
    return(if (diagnostics) "standard" else "none")
  }
  if (!is.character(diagnostics) || length(diagnostics) != 1L ||
      is.na(diagnostics)) {
    stop("`diagnostics` must be one of 'none', 'standard', or 'full'.",
         call. = FALSE)
  }
  match.arg(diagnostics, c("standard", "full", "none"))
}

kernel_code <- function(kernel) {
  choices <- c("gaussian", "bisquare", "exponential", "tricube", "boxcar")
  if (length(kernel) > 1L) kernel <- kernel[[1L]]
  kernel <- match.arg(kernel, choices)
  list(name = kernel, code = match(kernel, choices) - 1L)
}
