#ifndef GWRS_ACCELERATION_H
#define GWRS_ACCELERATION_H

#include "gwrs_common.h"
#include <limits>

namespace gwrs {

// Small-history Anderson extrapolation of complete coordinate sweeps.
// min ||sum a_j (T(b_j)-b_j)||, sum a_j=1; trial=sum a_j T(b_j).
// Solve the constrained least-squares problem via a small SVD, not a p-by-p
// inverse. The caller MUST safeguard using its original penalized objective.
// Related method: Bertrand & Massias (2021), PMLR 130:1288-1296.
class SweepAcceleration {
 public:
  static constexpr arma::uword history_size = 5;
  explicit SweepAcceleration(const arma::uword p)
    : outputs(p, history_size, arma::fill::zeros),
      differences(p, history_size, arma::fill::zeros) {}

  void clear() { count = 0; sweeps = 0; }

  bool propose(const arma::vec& before, const arma::vec& after,
               arma::vec& candidate) {
    // Keep an identified signed support; never extrapolate across a support
    // change. Screened coordinates therefore remain exactly zero.
    for (arma::uword j = 0; j < after.n_elem; ++j) {
      if (sign(before[j]) != sign(after[j])) { clear(); return false; }
    }
    if (count == history_size) {
      outputs.cols(0, history_size - 2) = outputs.cols(1, history_size - 1).eval();
      differences.cols(0, history_size - 2) = differences.cols(1, history_size - 1).eval();
      --count;
    }
    outputs.col(count) = after;
    differences.col(count) = after - before;
    ++count; ++sweeps;
    if (count < history_size || sweeps % history_size != 0) return false;

    arma::mat delta = differences.cols(0, count - 2);
    delta.each_col() -= differences.col(count - 1);
    arma::mat u, v;
    arma::vec singular;
    if (!delta.is_finite() || !arma::svd_econ(u, singular, v, delta, "both", "std") ||
        singular.is_empty() || singular.max() == 0.0) return false;
    const double cutoff = std::numeric_limits<double>::epsilon() *
      static_cast<double>(std::max(delta.n_rows, delta.n_cols)) * singular.max();
    arma::vec inverse = singular;
    for (arma::uword j = 0; j < inverse.n_elem; ++j)
      inverse[j] = singular[j] > cutoff ? 1.0 / singular[j] : 0.0;
    const arma::vec a = -v * (inverse % (u.t() * differences.col(count - 1)));
    if (!a.is_finite() || arma::accu(arma::abs(a)) > 1e12) return false;
    arma::mat output_delta = outputs.cols(0, count - 2);
    output_delta.each_col() -= outputs.col(count - 1);
    candidate = outputs.col(count - 1) + output_delta * a;
    if (!candidate.is_finite()) return false;
    // Clip at the first orthant boundary instead of rejecting an otherwise
    // useful extrapolation. The next ordinary sweep may change the support.
    // This is a solver line-segment safeguard, not coefficient thresholding.
    double step = 1.0;
    arma::uword boundary = after.n_elem;
    for (arma::uword j = 0; j < after.n_elem; ++j) {
      if (sign(after[j]) == 0) candidate[j] = 0.0;
      else if (after[j] * candidate[j] <= 0.0) {
        const double bound = -after[j] / (candidate[j] - after[j]);
        if (bound < step) { step = bound; boundary = j; }
      }
    }
    if (!std::isfinite(step) || step <= 0.0) return false;
    if (step < 1.0) {
      candidate = after + step * (candidate - after);
      candidate[boundary] = 0.0;
    }
    return true;
  }

 private:
  static int sign(const double value) {
    return std::abs(value) <= 1e-12 ? 0 : (value > 0.0 ? 1 : -1);
  }
  arma::mat outputs;
  arma::mat differences;
  arma::uword count = 0;
  arma::uword sweeps = 0;
};

// Recompute both residuals. Accept only a finite, strictly decreasing ORIGINAL
// objective. A rejected extrapolation leaves the CD iterate/residual untouched.
template<class Objective>
bool accept_acceleration(arma::vec& beta, arma::vec& residual,
                         const arma::vec& candidate, const arma::mat& x,
                         const arma::vec& y, const Objective& objective,
                         double& gain) {
  const arma::vec exact_residual = y - x * beta;
  const arma::vec trial_residual = y - x * candidate;
  const double current = objective(beta, exact_residual);
  const double trial = objective(candidate, trial_residual);
  if (!std::isfinite(current) || !std::isfinite(trial) || trial >= current) return false;
  gain = current - trial;
  beta = candidate;
  residual = trial_residual;
  return true;
}

} // namespace gwrs
#endif
