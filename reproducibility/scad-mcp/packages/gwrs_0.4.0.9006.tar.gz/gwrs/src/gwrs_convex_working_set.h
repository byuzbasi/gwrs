#ifndef GWRS_CONVEX_WORKING_SET_H
#define GWRS_CONVEX_WORKING_SET_H

#include "gwrs_convex_block.h"
#include <algorithm>

namespace gwrs {
constexpr int kConvexWorkingUpdates = 8;
constexpr int kConvexScreenFitBatches = 16;

struct ConvexWorkingResult {
  int status = 0, stop_reason = 0, qr_count = 0, updates = 0;
  int boundary_hits = 0, entries = 0, limit_hit = 0;
  arma::uword size = 0, support = 0;
  double gain = 0;
};

// Same status codes as ConvexBlockResult. The live iterate is touched only
// by the frozen full-objective acceptance guard at the end of this function.
inline ConvexWorkingResult apply_convex_working_set(
    const arma::mat& x, const arma::vec& y, const arma::vec& w,
    arma::vec& beta, arma::vec& residual, double l1, double l2) {
  ConvexWorkingResult out;
  if (x.n_rows != y.n_elem || y.n_elem != w.n_elem || residual.n_elem != y.n_elem ||
      x.n_cols != beta.n_elem || !y.is_finite() || !w.is_finite() ||
      arma::any(w < 0) || !(arma::accu(w) > 0) || !beta.is_finite() ||
      !residual.is_finite() || !std::isfinite(l1) || !(l1 > 0) ||
      !std::isfinite(l2) || l2 < 0) { out.status = 8; return out; }
  const arma::vec exact = y - x * beta;
  const arma::vec score = x.t() * (w % exact) - l2 * beta;
  if (!exact.is_finite() || !score.is_finite()) { out.status = 8; return out; }
  struct Priority { double violation; arma::uword column; };
  std::vector<Priority> priority;
  priority.reserve(beta.n_elem);
  for (arma::uword j = 0; j < beta.n_elem; ++j) {
    out.support += std::abs(beta[j]) > 1e-12;
    const double violation = beta[j] == 0 ? std::max(0.0, std::abs(score[j]) - l1) :
      std::abs(score[j] - std::copysign(l1, beta[j]));
    // Tiny nonzero coefficients are not silently snapped to zero.
    if (beta[j] != 0 || violation > 0) priority.push_back({violation, j});
  }
  out.size = std::min<arma::uword>(priority.size(), kConvexBlockMax);
  if (out.size == 0) { out.status = 1; return out; }
  const auto higher = [](const Priority& a, const Priority& b) {
    return a.violation > b.violation || (a.violation == b.violation && a.column < b.column);
  };
  std::partial_sort(priority.begin(), priority.begin() + out.size, priority.end(), higher);
  arma::uvec index(out.size);
  for (arma::uword j = 0; j < out.size; ++j) index[j] = priority[j].column;
  index = arma::sort(index); // Stable numerical order; ties above use column ID.
  const arma::mat design = x.cols(index);
  if (!design.is_finite()) { out.status = 8; return out; }
  arma::vec current = beta.elem(index);
  const arma::vec partial_y = exact + design * current;
  arma::vec local_residual = partial_y - design * current;
  const auto local_objective = [&](const arma::vec& b, const arma::vec& e) {
    return .5 * arma::dot(w % e, e) + l1 * arma::accu(arma::abs(b)) + .5 * l2 * arma::dot(b, b);
  };
  bool face_solved = false;
  for (int inner = 0; inner < kConvexWorkingUpdates; ++inner) {
    const arma::vec local_score = design.t() * (w % local_residual) - l2 * current;
    std::vector<arma::uword> free;
    for (arma::uword j = 0; j < out.size; ++j) if (current[j] != 0) free.push_back(j);
    arma::uword entry = out.size;
    if (face_solved || free.empty()) {
      double largest = 0;
      for (arma::uword j = 0; j < out.size; ++j) {
        const double violation = std::abs(local_score[j]) - l1;
        if (current[j] == 0 && violation > largest) { largest = violation; entry = j; }
      }
      if (entry == out.size && face_solved) break;
      if (entry < out.size) { free.push_back(entry); ++out.entries; }
    }
    if (free.empty()) break;
    const arma::uvec f(free);
    const arma::mat block = design.cols(f);
    if (l2 == 0 && block.n_cols > block.n_rows) { out.stop_reason = 2; break; }
    arma::mat z(block.n_rows + (l2 > 0 ? block.n_cols : 0), block.n_cols, arma::fill::zeros);
    z.head_rows(block.n_rows) = block;
    z.head_rows(block.n_rows).each_col() %= arma::sqrt(w);
    if (l2 > 0) z.tail_rows(block.n_cols).diag().fill(std::sqrt(l2));
    arma::mat q, r;
    ++out.qr_count;
    if (!arma::qr_econ(q, r, z) || !q.is_finite() || !r.is_finite()) { out.stop_reason = 2; break; }
    const double rc = arma::rcond(r);
    const double rank_floor = 64 * std::numeric_limits<double>::epsilon() *
      static_cast<double>(std::max(z.n_rows, z.n_cols));
    if (!std::isfinite(rc) || rc <= rank_floor) { out.stop_reason = 2; break; }
    arma::vec signs = arma::sign(current.elem(f));
    if (entry < out.size) signs[signs.n_elem - 1] = local_score[entry] > 0 ? 1 : -1;
    const arma::vec gradient = local_score.elem(f) - l1 * signs;
    arma::vec intermediate, direction;
    if (!arma::solve(intermediate, arma::trimatl(r.t()), gradient, arma::solve_opts::no_approx) ||
        !arma::solve(direction, arma::trimatu(r), intermediate, arma::solve_opts::no_approx) ||
        !direction.is_finite()) { out.stop_reason = 3; break; }
    double step = 1;
    for (arma::uword j = 0; j < f.n_elem; ++j) {
      const double b = current[f[j]];
      if (b == 0 && signs[j] * direction[j] <= 0) { step = 0; break; }
      if (b != 0 && b * (b + direction[j]) <= 0) step = std::min(step, -b / direction[j]);
    }
    if (!std::isfinite(step) || step <= 0) { out.stop_reason = 4; break; }
    arma::vec candidate = current;
    candidate.elem(f) += step * direction;
    int hits = 0;
    for (arma::uword j = 0; j < f.n_elem; ++j) {
      const double b = current[f[j]];
      if (b != 0 && b * direction[j] < 0 && -b / direction[j] <= step) {
        candidate[f[j]] = 0; ++hits;
      }
    }
    const arma::vec trial = partial_y - design * candidate;
    const double before = local_objective(current, local_residual), after = local_objective(candidate, trial);
    if (!candidate.is_finite() || !trial.is_finite() || !std::isfinite(before) || !std::isfinite(after)) {
      out.stop_reason = 6; break;
    }
    if (!(after < before)) { out.stop_reason = 5; break; }
    current = candidate; local_residual = trial;
    ++out.updates; out.boundary_hits += hits;
    face_solved = step == 1 && hits == 0;
    if (inner + 1 == kConvexWorkingUpdates) out.limit_hit = 1;
  }
  arma::vec candidate = beta;
  candidate.elem(index) = current;
  const auto objective = [&](const arma::vec& b, const arma::vec& e) {
    return .5 * arma::dot(w % e, e) + l1 * arma::accu(arma::abs(b)) + .5 * l2 * arma::dot(b, b);
  };
  if (!accept_acceleration(beta, residual, candidate, x, y, objective, out.gain)) {
    out.status = out.stop_reason ? out.stop_reason : 5; return out;
  }
  out.status = 7;
  return out;
}
} // namespace gwrs
#endif
