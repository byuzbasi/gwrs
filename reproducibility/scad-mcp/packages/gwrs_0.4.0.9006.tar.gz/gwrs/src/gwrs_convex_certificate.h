#ifndef GWRS_CONVEX_CERTIFICATE_H
#define GWRS_CONVEX_CERTIFICATE_H

#include "gwrs_common.h"

namespace gwrs {

constexpr double kConvexDualityToleranceMultiplier = 10.0;

struct ConvexCertificate {
  double kkt = arma::datum::inf;
  double primal = arma::datum::inf;
  double dual = -arma::datum::inf;
  double gap = arma::datum::inf;
  double relative_gap = arma::datum::inf;
  arma::vec score;
  bool finite = false;
};

inline double convex_duality_bound(const double tolerance) {
  const double numerical_floor = 256.0 * std::numeric_limits<double>::epsilon();
  return std::max(kConvexDualityToleranceMultiplier * tolerance,
                  numerical_floor);
}

inline double convex_coordinate_kkt_violation(
    const double score, const double beta,
    const double l1, const double l2) {
  const double stationarity = score - l2 * beta;
  return std::abs(beta) <= 1e-12
    ? std::max(0.0, std::abs(score) - l1)
    : std::abs(stationarity - std::copysign(l1, beta));
}

// Joint optimality certificate for the weighted, centered Lasso/elastic-net
// objective used by the d = 0 convex path. The score is formed once and reused
// for the full KKT residual and the Fenchel dual objective.
inline ConvexCertificate convex_certificate(
    const arma::mat& x, const arma::vec& y, const arma::vec& w,
    const arma::vec& beta, const arma::vec& residual,
    const double l1, const double l2) {
  ConvexCertificate out;
  if (x.n_rows != y.n_elem || y.n_elem != w.n_elem ||
      residual.n_elem != y.n_elem || x.n_cols != beta.n_elem ||
      !x.is_finite() || !y.is_finite() || !w.is_finite() ||
      !beta.is_finite() || !residual.is_finite() || arma::any(w < 0) ||
      !(arma::accu(w) > 0) || !std::isfinite(l1) || !(l1 > 0) ||
      !std::isfinite(l2) || l2 < 0) return out;

  const arma::vec weighted_residual = w % residual;
  out.score = x.t() * weighted_residual;
  if (!weighted_residual.is_finite() || !out.score.is_finite()) return out;

  out.kkt = 0.0;
  for (arma::uword j = 0; j < beta.n_elem; ++j) {
    const double violation = convex_coordinate_kkt_violation(
      out.score[j], beta[j], l1, l2);
    out.kkt = std::max(out.kkt, violation);
  }

  const double loss = 0.5 * arma::dot(weighted_residual, residual);
  out.primal = loss + l1 * arma::accu(arma::abs(beta)) +
    0.5 * l2 * arma::dot(beta, beta);
  const double response_pairing = arma::dot(w % y, residual);
  if (l2 == 0.0) {
    const double maximum_score = arma::max(arma::abs(out.score));
    const double scale = maximum_score == 0.0
      ? 1.0 : std::min(1.0, l1 / maximum_score);
    out.dual = scale * response_pairing - scale * scale * loss;
  } else {
    double conjugate = 0.0;
    for (arma::uword j = 0; j < out.score.n_elem; ++j) {
      const double excess = std::max(0.0, std::abs(out.score[j]) - l1);
      conjugate += excess * excess;
    }
    out.dual = response_pairing - loss - conjugate / (2.0 * l2);
  }

  if (!std::isfinite(out.kkt) || !std::isfinite(out.primal) ||
      !std::isfinite(out.dual)) return out;
  const double raw_gap = out.primal - out.dual;
  const double roundoff = 256.0 * std::numeric_limits<double>::epsilon() *
    (1.0 + std::abs(out.primal) + std::abs(out.dual));
  if (!std::isfinite(raw_gap) || raw_gap < -roundoff) return out;
  out.gap = std::max(0.0, raw_gap);
  out.relative_gap = out.gap / (1.0 + std::abs(out.primal));
  out.finite = std::isfinite(out.relative_gap);
  return out;
}

} // namespace gwrs

#endif
