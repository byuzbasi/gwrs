#ifndef GWRS_CONVEX_BLOCK_H
#define GWRS_CONVEX_BLOCK_H

#include "gwrs_acceleration.h"

namespace gwrs {
constexpr arma::uword kConvexBlockMax = 128;
constexpr int kConvexBlockEvery = 25;
constexpr int kConvexBlockStable = 5;

inline int convex_block_sign(double value) {
  return std::abs(value) <= 1e-12 ? 0 : (value > 0 ? 1 : -1);
}
inline bool convex_same_support(const arma::vec& a, const arma::vec& b) {
  for (arma::uword j = 0; j < a.n_elem; ++j)
    if (convex_block_sign(a[j]) != convex_block_sign(b[j])) return false;
  return true;
}

// Status: 1 size, 2 rank/QR, 3 triangular solve, 4 invalid direction/clip,
// 5 nondecrease, 6 nonfinite objective, 7 accepted, 8 invalid input.
// Every rejection is non-mutating. No artificial ridge, inverse or Gram matrix.
struct ConvexBlockResult {
  int status = 0;
  arma::uword size = 0;
  double gain = 0, delta = 0, step = arma::datum::nan, rcond = arma::datum::nan;
};

inline ConvexBlockResult apply_convex_block(
    const arma::mat& x, const arma::vec& y, const arma::vec& w,
    arma::vec& beta, arma::vec& residual, double l1, double l2) {
  ConvexBlockResult out;
  if (x.n_rows != y.n_elem || y.n_elem != w.n_elem || residual.n_elem != y.n_elem ||
      x.n_cols != beta.n_elem || !y.is_finite() || !w.is_finite() ||
      arma::any(w < 0) || !(arma::accu(w) > 0) || !beta.is_finite() ||
      !residual.is_finite() || !std::isfinite(l1) || !(l1 > 0) ||
      !std::isfinite(l2) || l2 < 0) { out.status = 8; return out; }
  std::vector<arma::uword> selected;
  selected.reserve(kConvexBlockMax);
  for (arma::uword j = 0; j < beta.n_elem; ++j) {
    if (convex_block_sign(beta[j]) == 0) continue;
    ++out.size;
    if (selected.size() < kConvexBlockMax) selected.push_back(j);
  }
  if (out.size < 2 || out.size > kConvexBlockMax || (l2 == 0 && x.n_rows < out.size)) {
    out.status = 1; return out;
  }
  const arma::uvec index(selected);
  const arma::vec current = beta.elem(index);
  const arma::mat block = x.cols(index);
  if (!block.is_finite()) { out.status = 8; return out; }
  arma::mat z(x.n_rows + (l2 > 0 ? out.size : 0), out.size, arma::fill::zeros);
  z.head_rows(x.n_rows) = block;
  z.head_rows(x.n_rows).each_col() %= arma::sqrt(w);
  // This is exactly the existing EN penalty, not numerical regularization.
  if (l2 > 0) z.tail_rows(out.size).diag().fill(std::sqrt(l2));
  arma::mat q, r;
  if (!arma::qr_econ(q, r, z) || !q.is_finite() || !r.is_finite()) {
    out.status = 2; return out;
  }
  out.rcond = arma::rcond(r);
  const double rank_floor = 64 * std::numeric_limits<double>::epsilon() *
    static_cast<double>(std::max(z.n_rows, z.n_cols));
  if (!std::isfinite(out.rcond) || out.rcond <= rank_floor) { out.status = 2; return out; }
  // On a fixed orthant Q is quadratic plus the LINEAR l1*s'b term.
  // R' R delta = X_S' W (y-X beta) - l2*beta_S - l1*sign(beta_S).
  // The triangular solves avoid explicitly forming R'R or a p-by-p Gram.
  const arma::vec exact = y - x * beta;
  const arma::vec gradient = block.t() * (w % exact) - l2 * current - l1 * arma::sign(current);
  arma::vec intermediate, direction;
  if (!arma::solve(intermediate, arma::trimatl(r.t()), gradient, arma::solve_opts::no_approx) ||
      !arma::solve(direction, arma::trimatu(r), intermediate, arma::solve_opts::no_approx) ||
      !direction.is_finite()) { out.status = 3; return out; }
  double step = 1;
  arma::uword boundary = out.size;
  for (arma::uword j = 0; j < out.size; ++j) {
    if (current[j] * (current[j] + direction[j]) <= 0) {
      const double bound = -current[j] / direction[j];
      if (bound < step) { step = bound; boundary = j; }
    }
  }
  if (!std::isfinite(step) || step <= 0) { out.status = 4; return out; }
  arma::vec candidate = beta;
  candidate.elem(index) = current + step * direction;
  if (boundary < out.size) candidate[index[boundary]] = 0;
  out.step = step;
  out.delta = arma::abs(candidate.elem(index) - current).max();
  const auto objective = [&](const arma::vec& b, const arma::vec& e) {
    return .5 * arma::dot(w % e, e) + l1 * arma::accu(arma::abs(b)) + .5 * l2 * arma::dot(b, b);
  };
  // Reuse the frozen, full original-objective acceptance guard.
  const arma::vec trial_residual = y - x * candidate;
  const double before = objective(beta, exact), after = objective(candidate, trial_residual);
  if (!std::isfinite(before) || !std::isfinite(after)) { out.status = 6; return out; }
  if (!accept_acceleration(beta, residual, candidate, x, y, objective, out.gain)) {
    out.status = 5; return out;
  }
  out.status = 7;
  return out;
}
} // namespace gwrs
#endif
