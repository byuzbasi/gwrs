## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(gwrs)

## ----example------------------------------------------------------------------
set.seed(1401)
dat <- data.frame(east = runif(28), north = runif(28),
                  x1 = rnorm(28), x2 = rnorm(28))
dat$y <- 1 + (1 + dat$east) * dat$x1 + rnorm(28, sd = 0.5)
selection <- gwr_select(y ~ x1 + x2, dat, c("east", "north"),
  kernels = c("bisquare", "gaussian"), k = c(20, 28),
  control = gwrs_control(n_threads = 1), verbose = FALSE)
selection
knitr::kable(selection$best_by_criterion[, c("criterion", "comparison",
  "terms", "kernel", "k", "criterion_value")], digits = 3)

## ----local-inference----------------------------------------------------------
local <- selection$local_inference
local$status
display <- head(local$local[, c("location", "coefficient", "estimate",
  "standard_error", "statistic", "p_value", "p_adjusted")])
display$p_value <- format.pval(display$p_value, digits = 3)
display$p_adjusted <- format.pval(display$p_adjusted, digits = 3)
knitr::kable(display, digits = 4)
local$settings[c("adjust", "adjust_scope", "exploratory",
                 "reference_calibrated", "selection_conditioned")]

## ----global-local-adjustment--------------------------------------------------
all_local_tests <- gwr_local_inference(selection, adjust = "BH",
                                       adjust_scope = "global")
all_local_tests$summary

## ----design-------------------------------------------------------------------
design <- gwr_select(y ~ x1 + x2, dat, c("east", "north"), dry_run = TRUE)
design

## ----checkpoint-template, eval=FALSE------------------------------------------
# run_dir <- "results/gwr-selection-v01"
# partial <- gwr_select(y ~ x1 + x2, dat, c("east", "north"),
#   k = c(20, 28), checkpoint = run_dir, max_evaluations = 10,
#   control = gwrs_control(n_threads = 1))
# gwr_select_verify(run_dir)
# finished <- gwr_select(y ~ x1 + x2, dat, c("east", "north"),
#   k = c(20, 28), checkpoint = run_dir, resume = TRUE,
#   control = gwrs_control(n_threads = 1))
# gwr_select_verify(run_dir)

