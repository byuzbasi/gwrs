# SCAD/MCP reproduction materials

Open scad-mcp/README.md for independent installation and commands for the
simulation and county application. Both historical estimation engines and
the public input snapshot are included. See scad-mcp/VALIDATION.md for checks
and limitations. No full numerical run starts automatically.

The separate gwrs_0.4.0.9013.tar.gz archive is the current package, including
acs2024_counties. It is not substituted for the historical engines during
paper reproduction. Install it with R CMD INSTALL only when you want the
current package and its documented dataset.

Author: Bahadir Yuzbasi. Software license: GPL (>= 3).
Source data: U.S. Census Bureau; see scad-mcp/SOURCES.md.
